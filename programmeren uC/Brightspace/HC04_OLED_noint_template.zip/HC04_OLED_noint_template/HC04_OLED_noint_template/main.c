/*
 * HC04_OLED_noint_template.c
 *
 * Created: 16-1-2023 21:16:59
 * Author : mw0057672
 */ 


#define F_CPU                           (4000000UL)         /* using 4 MHz osc */

#include <stdio.h>
#include <avr/io.h>
#include <avr/cpufunc.h>
#include <util/delay.h>
#include <string.h>
#include "OLED/SSD1306.h"
#include "OLED/Font5x8.h"

#define TIMER_PERIOD        0xF000   // 0xF000 = 15x4096x0.25 us = 15.36 ms
uint16_t distance_count = 0;
uint16_t distance_mm;

static void PORT_init(void)
{
	PORTB.DIR |= PIN4_bm;  // set PB4 as output (trig pin HC04)
	PORTB.OUT &= ~PIN4_bm;  // PB4 low
	
	PORTB.DIR &= ~PIN5_bm; //set PB5 as input  (echo pin HC04)
}


void TCA0_init(void)
{
	TCA0.SINGLE.PER = TIMER_PERIOD;
	TCA0.SINGLE.CTRLA = TCA_SINGLE_CLKSEL_DIV1_gc; // 23.5.1 DIV1 CLKSEL=0x00
	TCA0.SINGLE.CTRLA |= TCA_SINGLE_ENABLE_bm;
}


/* blocking function to measure distance HC-SR04 in mm*/
uint16_t distance_blocking(){
	/* Make a 15us trigger pulse on trig pin to HC-SR04 */
	//setting up TCA0 For time measurements
	TCA0_init();
	PORTB.OUT |= PIN4_bm;    // PB4 high trig pin
	_delay_us(10);
	PORTB.OUT &= ~PIN4_bm;    // PB4 low trig pin
	/* Wait for rising edge on PB5 echo pin */
	while(!(PORTB.IN & PIN5_bm)){ 
	}
	TCA0.SINGLE.CNT = 0;  // reset timer
    while(PORTB.IN & PIN5_bm){ 
	} 
    distance_count = TCA0.SINGLE.CNT;
	distance_count=distance_count/23;  // distance calculation  : distance in millimeter
	return distance_count;
}

int main(void)
{
	char buffer[12];
	uint16_t i = 0;
	PORT_init();
    GLCD_Setup();
    GLCD_SetFont(Font5x8, 5, 8, GLCD_Overwrite);
    	
    while (1){
		distance_mm = distance_blocking();
	   	GLCD_GotoXY(10,50);
	   	sprintf(buffer, "%5d mm", distance_mm);
	   	GLCD_PrintString(buffer);
	    GLCD_Render();
	}
}



