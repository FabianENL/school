/*
 * HC04_OLED_template.c
 *
 * Created: 16-1-2023 13:48:50
 * Author : mw0057672
 */ 

#define F_CPU                           (4000000UL)         /* using 4 MHz osc */

#include <stdio.h>
#include <avr/io.h>
#include <avr/cpufunc.h>
#include <util/delay.h>
#include <string.h>
#include "OLED/SSD1306.h"
#include "OLED/Font5x8.h"
#include <avr/sleep.h>
#include <avr/interrupt.h>

#define TIMER_PERIOD        0xF000   // 0xF000 = 15x4096x0.25 us = 15.36 ms
uint16_t distance_count = 0;
uint16_t distance_mm;
	
static void SLPCTRL_init(void)
{
	SLPCTRL.CTRLA = SLPCTRL_SMODE_IDLE_gc; // prepare for Idle sleep mode
}

static void PORT_init(void)
{
	PORTB.DIR |= PIN4_bm;  // set PB4 as output (trig pin HC04)
	PORTB.OUT &= ~PIN4_bm;  // PB4 low
	
	PORTB.DIR &= ~PIN5_bm; //set PB5 as input  (echo pin HC04)
    PORTB.PIN5CTRL |= PORT_ISC_FALLING_gc; // enable interrupt on falling edge
}


void TCA0_interrupt_init(void)
{
	TCA0.SINGLE.INTCTRL = TCA_SINGLE_OVF_bm;         // set interrupt on timer overflow bit
	TCA0.SINGLE.PER = TIMER_PERIOD;
	TCA0.SINGLE.CTRLA = TCA_SINGLE_CLKSEL_DIV1_gc; // 23.5.1 DIV1 CLKSEL=0x00
	TCA0.SINGLE.CTRLA |= TCA_SINGLE_ENABLE_bm;
	// don't forget to set Global Interrupt Enable bit using sei()
}

ISR(TCA0_OVF_vect) {
	distance_count = 0;    // in case of overflow set distance 0
    //TCA0.SINGLE.CTRLA = 0;   // disable timer
	TCA0.SINGLE.INTFLAGS = TCA_SINGLE_OVF_bm;
}

ISR(PORTB_PORT_vect)
{
	distance_count = TCA0.SINGLE.CNT;
	//TCA0.SINGLE.CTRLA = 0;   // disable timer
	PORTB.INTFLAGS = PIN5_bm;
}

/* blocking function to measure distance HC-SR04 in mm*/
uint16_t distance_blocking(){
	/* Make a 15us trigger pulse on trig pin to HC-SR04 */
	//setting up TCA0 For time measurements
	TCA0_interrupt_init();
	TCA0.SINGLE.INTFLAGS = TCA_SINGLE_OVF_bm;
	
	PORTB.OUT |= PIN4_bm;    // PB4 high trig pin
	_delay_us(10);
	PORTB.OUT &= ~PIN4_bm;    // PB4 low trig pin
    sei();// enable global Interrupts
	/* Wait for rising edge on PB5 echo pin */
	while(!(PORTB.IN & PIN5_bm)){ 
	}
	TCA0.SINGLE.CNT = 0;  // reset timer
	
    /* while(PORTB.IN & PIN5_bm){ 
	} */
    
	/* Wait for falling edge on PB2 echo pin or timeout*/
	sleep_mode();    // go to Idle sleep mode, this blocks as CPU is idle
    // we arrive here after waking up from Idle sleep and executing PORT ISR
	cli();//disable global Interrupts
	distance_count = distance_count/23; // distance calculation  : distance in millimeter
	return distance_count;
}

int main(void)
{
	char buffer[12];
	uint16_t i = 0;
	PORT_init();
    SLPCTRL_init();  
    GLCD_Setup();
    GLCD_SetFont(Font5x8, 5, 8, GLCD_Overwrite);
    	
    while (1){
		distance_mm = distance_blocking();
	   	GLCD_GotoXY(10,50);
	   	sprintf(buffer, "%5d mm", distance_mm);
	   	GLCD_PrintString(buffer);
	    GLCD_Render();
	}
}

