/*
 * GPIO_ISR_template.c
 * When the button SW0 is pressed, the CPU wakes up and blinks the LED0. After those operations, the CPU returns to Sleep Mode
 * Created: 6-12-2022 08:24:43
 * Author : mw0057672
 */ 

#define F_CPU           4000000UL

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>

static void PORT_init(void);
static void SLPCTRL_init(void);

static void PORT_init(void)
{
    PORTB.DIR |= PIN3_bm;  // set PB3 (LED0) as output
    PORTB.OUT |= PIN3_bm;  // LED0 high = off

    PORTB.DIR &= ~PIN2_bm; //set PB2 (SW0) as input
    PORTB.PIN2CTRL |= PORT_PULLUPEN_bm | PORT_ISC_FALLING_gc; // enable pull up resistor, enable interrupt on falling edge
}

static void SLPCTRL_init(void)
{
    SLPCTRL.CTRLA = SLPCTRL_SMODE_IDLE_gc; // prepare for Idle sleep mode
}

ISR(PORTB_PORT_vect)
{
    PORTB.OUT &= ~PIN3_bm;    // LED0 low = on
    PORTB.INTFLAGS = PIN2_bm;
}

int main(void)
{
    PORT_init();
    SLPCTRL_init();  
    sei();

    while (1) 
    {
        sleep_mode();    // go to Idle sleep mode, this blocks as CPU is idle
        // we arrive here after waking up from Idle sleep and executing PORT ISR
		_delay_ms(200);

        PORTB.OUT |= PIN3_bm;  // LED0 high = off
    }
}


