/*
 * PWM_template.c
 * using Timer TCA0 in split mode to access WO(n+3)
 * Created: 5-12-2022 22:24:15
 * Author : Jan Kampen, Marco Winkelman
 */ 
#define PERIOD_EXAMPLE_VALUE			(0xFA)                    // 0xFF = max value, 0xFA = 250, adjust to fine tune PWM frequency, now 4M/16/250 = ~1 kHz
#define DUTY_CYCLE_EXAMPLE_VALUE		(PERIOD_EXAMPLE_VALUE>>2) // 0xFA>>2 = 0x3E = ~25% duty cycle, make sure not too exceed PERIOD_EXAMPLE_VALUE
//#define DUTY_CYCLE						(10) // unit: %
//#define DUTY_CYCLE_EXAMPLE_VALUE_10	(PERIOD_EXAMPLE_VALUE*DUTY_CYCLE/100) // make relative to Period

#include <avr/io.h>
/*Using default clock 4MHz */
#define F_CPU 4000000UL
#include <util/delay.h>

void PORT_init(void);
void TCA0_PWM_init(void);

void PORT_init(void)
{
	PORTB.DIRSET = PIN3_bm;						    /* direct timer PWM output on PB3 (LED0), set pin 3 of PORT B as output */
	//PORTC.DIRSET = PIN1_bm;						// example for PWM output on port Pxn, x=A..G, n = 0,1,2
}

void TCA0_PWM_init(void)
{
	// use port PB3 as output, which is connected to WO3 in TCAROUTE register (see ioavr128db48.h PORTMUX_TCA0_enum p165 17.3.7)
	PORTMUX.TCAROUTEA = PORTMUX_TCA0_PORTB_gc;

	// p238: use timer in split mode, HCMP to access WO(n+3) WO3 -> n=0 HCMP0
	TCA0.SPLIT.CTRLB = TCA_SPLIT_HCMP0EN_bm;
	
	TCA0.SPLIT.HPER = PERIOD_EXAMPLE_VALUE;
	
	// HCMP0 gives WO[n+3] = WO3 -> n=0 as output
	TCA0.SPLIT.HCMP0 = DUTY_CYCLE_EXAMPLE_VALUE;
    // coarse adjust the PWM frequency with the divider, now 4M/16/250 = ~1kHz
	TCA0.SPLIT.CTRLA = TCA_SPLIT_CLKSEL_DIV16_gc | TCA_SPLIT_ENABLE_bm;
	TCA0.SPLIT.CTRLD = TCA_SPLIT_ENABLE_bm;
}

// example for PWM output on port Pxn, x=A..G, n = 0,1,2
/*void TCA0_PWM_init(void)
{
	// example using port PC1 as output, which is connected to WO1 in TCAROUTE register
	PORTMUX.TCAROUTEA = PORTMUX_TCA0_PORTC_gc;

	// to access WO0..WO2 use LCMP, e.g. for PC1, use WO1 (LCMP1)
	TCA0.SPLIT.CTRLB = TCA_SPLIT_LCMP1EN_bm;

	TCA0.SPLIT.LPER = PERIOD_EXAMPLE_VALUE;
	
	// LCMP0 gives WOn = WO1 as output
	TCA0.SPLIT.LCMP1 = DUTY_CYCLE_EXAMPLE_VALUE;
    // coarse adjust the PWM frequency with the divider, now 4M/16/250 = ~1kHz
	TCA0.SPLIT.CTRLA = TCA_SPLIT_CLKSEL_DIV16_gc | TCA_SPLIT_ENABLE_bm;
	TCA0.SPLIT.CTRLD = TCA_SPLIT_ENABLE_bm;
}*/


int main(void)
{
	PORT_init();
	
	TCA0_PWM_init();
	
	while (1)
	{
		TCA0.SPLIT.HCMP0 = DUTY_CYCLE_EXAMPLE_VALUE; // PWM on example duty cycle 
		//TCA0.SPLIT.LCMP1 = DUTY_CYCLE_EXAMPLE_VALUE; // use LCMPn for WOn n=0,1,2
		_delay_ms(1000);
		TCA0.SPLIT.HCMP0 = PERIOD_EXAMPLE_VALUE - DUTY_CYCLE_EXAMPLE_VALUE; // PWM on inverse example duty cycle
		//TCA0.SPLIT.LCMP1 = PERIOD_EXAMPLE_VALUE - DUTY_CYCLE_EXAMPLE_VALUE;
		_delay_ms(1000);
	}
}