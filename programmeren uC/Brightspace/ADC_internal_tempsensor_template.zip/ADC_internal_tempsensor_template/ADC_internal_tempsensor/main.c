/*
 * ADC_internal_tempsensor_template.c
 *
 * Created: 3-2-2023 19:00:19
 * Author : mw0057672
 * Based on ADC Sample Accumulator (c) 2019 Microchip Technology Inc. and its subsidiaries.
 * This template reads the internal temperature sensor
 *
 */ 

#define F_CPU                           (16000000UL)         /* using 16 MHz crystal */

#include <avr/io.h>
#include <avr/cpufunc.h>
#include <util/delay.h>
#include <stdbool.h>

#define ADC_SHIFT_DIV16					(4)   /* where 4 is 2^4 = 16 */

volatile	uint16_t adcVal;
uint16_t adc_reading, temperature_in_K;
uint32_t temp;


void CLOCK_XOSCHF_crystal_init(void)
{
	/* Enable crystal oscillator with frequency range 16 MHz and 4K cycles start-up time */
	ccp_write_io((uint8_t *) &CLKCTRL.XOSCHFCTRLA, CLKCTRL_RUNSTDBY_bm
	| CLKCTRL_CSUTHF_4K_gc
	| CLKCTRL_FRQRANGE_16M_gc
	| CLKCTRL_SELHF_XTAL_gc
	| CLKCTRL_ENABLE_bm);

	/* Confirm crystal oscillator start-up */
	while(!(CLKCTRL.MCLKSTATUS & CLKCTRL_EXTS_bm));

	/* Clear Main Clock Prescaler */
	ccp_write_io((uint8_t *) &CLKCTRL.MCLKCTRLB, 0x00);

	/* Set the main clock to use XOSCHF as source, and enable the CLKOUT pin */
	ccp_write_io((uint8_t *) &CLKCTRL.MCLKCTRLA, CLKCTRL_CLKSEL_EXTCLK_gc | CLKCTRL_CLKOUT_bm);

	/* Wait for system oscillator changing to complete */
	while(CLKCTRL.MCLKSTATUS & CLKCTRL_SOSC_bm);

	/* Clear RUNSTDBY for power save during sleep */
	ccp_write_io((uint8_t *) &CLKCTRL.XOSCHFCTRLA, CLKCTRL.XOSCHFCTRLA & ~CLKCTRL_RUNSTDBY_bm);

	/* Change complete and the main clock is 16 MHz */
}

static void VREF0_init(void)
{
    VREF.ADC0REF = VREF_REFSEL_2V048_gc;		/* 2.048V VDD as reference */
}

static void ADC0_init(void)
{
    ADC0.CTRLC = ADC_PRESC_DIV16_gc;       /* CLK_PER divided by 16 to obtain 1 MHz*/
    ADC0.CTRLA = ADC_ENABLE_bm             /* ADC Enable: enabled */
               | ADC_RESSEL_12BIT_gc       /* 12-bit mode */
               | ADC_FREERUN_bm;           /* Enable Free-Run mode */
    ADC0.MUXPOS = ADC_MUXPOS_TEMPSENSE_gc; //ADC_MUXPOS_AIN4_gc;      /* Select ADC channel AIN4 <-> PD4 */
    ADC0.CTRLB = ADC_SAMPNUM_ACC16_gc;     /* Set to accumulate 16 samples, 
	if added accuracy not required, remove or set to ADC_SAMPNUM_NONE_gc */
}

static uint16_t ADC0_read(void)
{
    /* Clear the interrupt flag by reading the result */
    return ADC0.RES;
}

static void ADC0_start(void)
{
    /* Start ADC conversion */
    ADC0.COMMAND = ADC_STCONV_bm;
}

static bool ADC0_conversionDone(void)
{
    /* Check if the conversion is done  */
    return (ADC0.INTFLAGS & ADC_RESRDY_bm);
}

static void SYSTEM_init(void)
{
    CLOCK_XOSCHF_crystal_init();
	VREF0_init();
    ADC0_init();
}

int main(void)
{
	SYSTEM_init();
    ADC0_start();  /* ADC is in Free-Run mode, only start once */
	
	uint16_t sigrow_offset = SIGROW.TEMPSENSE1; // Read unsigned value from signature row
    uint16_t sigrow_slope = SIGROW.TEMPSENSE0; // Read unsigned value from signature row


    while (1)
    {
			if (ADC0_conversionDone())
			{
				adc_reading = ADC0_read() >> ADC_SHIFT_DIV16; // ADC conversion result divide by No of samples or 16, if No. samples > 16 
				temp = sigrow_offset - adc_reading;
				temp *= sigrow_slope; // Result will overflow 16-bit variable
				temp += 0x0800; // Add 4096/2 to get correct rounding on division below
				temp >>= 12; // Round off to nearest degree in Kelvin, by dividing with 2^12 (4096)
				temperature_in_K = temp;
				_delay_us(100);
			}
    }
}



