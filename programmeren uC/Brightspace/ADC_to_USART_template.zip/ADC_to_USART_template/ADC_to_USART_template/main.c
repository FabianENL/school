/*
 * ADC_to_USART_template.c
 *
 * Created: 29-1-2023 20:44:25
 * Author : mw0057672
 * Based on ADC Sample Accumulator (c) 2019 Microchip Technology Inc. and its subsidiaries.
 * This template reads the potentiometer on the SMU connected to PD4 in 12 bit, free run mode, with 16 samples accumulated
 * and outputs only the most significant 8 bits to the USART3 (PC)
 *
 */ 

#define F_CPU                           (16000000UL)         /* using 16 MHz crystal */

#include <avr/io.h>
#include <stdio.h>
#include <avr/cpufunc.h>
#include <util/delay.h>
#include <stdbool.h>
#include <string.h>

#define ADC_SHIFT_DIV16					(4)   /* where 4 is 2^4 = 16 */
#define USART3_BAUD_RATE(BAUD_RATE)     ((float)(64 * F_CPU / (16 * (float)BAUD_RATE)) + 0.5)

volatile	uint16_t adcVal, temp;

// USART3 is the port connected to the PC
void USART3_init(void)
{
	// AVR128DB48
	PORTB.DIRSET = PIN0_bm;										/* set pin 0 of PORT B (TXd) as output*/
	PORTB.DIRCLR = PIN1_bm;										/* set pin 1 of PORT B (RXd) as input*/
	
	USART3.BAUD = (uint16_t)(USART3_BAUD_RATE(115200));			/* set the baud rate*/
	
	USART3.CTRLC = USART_CHSIZE0_bm	| USART_CHSIZE1_bm;			/* set the data format to 8-bit*/
	
	USART3.CTRLB |= USART_TXEN_bm;								/* enable transmitter*/
}

void USART3_sendChar(char c)
{
	while(!(USART3.STATUS & USART_DREIF_bm));
	
	USART3.TXDATAL = c;
}

void USART3_sendString(char *str)
{
	for(size_t i = 0; i < strlen(str); i++)
	{
		USART3_sendChar(str[i]);
	}
}

void CLOCK_XOSCHF_crystal_init(void)
{
	/* Enable crystal oscillator with frequency range 16 MHz and 4K cycles start-up time */
	ccp_write_io((uint8_t *) &CLKCTRL.XOSCHFCTRLA, CLKCTRL_RUNSTDBY_bm
	| CLKCTRL_CSUTHF_4K_gc
	| CLKCTRL_FRQRANGE_16M_gc
	| CLKCTRL_SELHF_XTAL_gc
	| CLKCTRL_ENABLE_bm);

	/* Confirm crystal oscillator start-up */
	while(!(CLKCTRL.MCLKSTATUS & CLKCTRL_EXTS_bm));

	/* Clear Main Clock Prescaler */
	ccp_write_io((uint8_t *) &CLKCTRL.MCLKCTRLB, 0x00);

	/* Set the main clock to use XOSCHF as source, and enable the CLKOUT pin */
	ccp_write_io((uint8_t *) &CLKCTRL.MCLKCTRLA, CLKCTRL_CLKSEL_EXTCLK_gc | CLKCTRL_CLKOUT_bm);

	/* Wait for system oscillator changing to complete */
	while(CLKCTRL.MCLKSTATUS & CLKCTRL_SOSC_bm);

	/* Clear RUNSTDBY for power save during sleep */
	ccp_write_io((uint8_t *) &CLKCTRL.XOSCHFCTRLA, CLKCTRL.XOSCHFCTRLA & ~CLKCTRL_RUNSTDBY_bm);

	/* Change complete and the main clock is 16 MHz */
}


static void PORT_init(void)
{
    /* Disable interrupt and digital input buffer on PD4 */
    PORTD.PIN4CTRL &= ~PORT_ISC_gm;
    PORTD.PIN4CTRL |= PORT_ISC_INPUT_DISABLE_gc;

    /* Disable pull-up resistor */
    PORTD.PIN4CTRL &= ~PORT_PULLUPEN_bm;
}

static void VREF0_init(void)
{
    VREF.ADC0REF = VREF_REFSEL_VDD_gc;		/* VDD as reference */
}

static void ADC0_init(void)
{
    ADC0.CTRLC = ADC_PRESC_DIV16_gc;       /* CLK_PER divided by 16 to obtain 1 MHz*/
    ADC0.CTRLA = ADC_ENABLE_bm             /* ADC Enable: enabled */
               | ADC_RESSEL_12BIT_gc       /* 12-bit mode */
               | ADC_FREERUN_bm;           /* Enable Free-Run mode */
    ADC0.MUXPOS = ADC_MUXPOS_AIN4_gc;      /* Select ADC channel AIN4 <-> PD4 */
    ADC0.CTRLB = ADC_SAMPNUM_ACC16_gc;     /* Set to accumulate 16 samples, 
	if added accuracy not required, remove or set to ADC_SAMPNUM_NONE_gc */
}

static uint16_t ADC0_read(void)
{
    /* Clear the interrupt flag by reading the result */
    return ADC0.RES;
}

static void ADC0_start(void)
{
    /* Start ADC conversion */
    ADC0.COMMAND = ADC_STCONV_bm;
}

static bool ADC0_conversionDone(void)
{
    /* Check if the conversion is done  */
    return (ADC0.INTFLAGS & ADC_RESRDY_bm);
}

static void SYSTEM_init(void)
{
    PORT_init();
    CLOCK_XOSCHF_crystal_init();
	USART3_init();
	VREF0_init();
    ADC0_init();
}

int main(void)
{
	SYSTEM_init();
    ADC0_start();  /* ADC is in Free-Run mode, only start once */
    while (1)
    {
			if (ADC0_conversionDone())
			{
				adcVal = ADC0_read();
				/* divide by No of samples or 16, if No. samples > 16 */
				temp = adcVal >> ADC_SHIFT_DIV16;
				USART3_sendChar((char)(temp>>4));  // convert from 12 bit to 8 bit to stream on usart3
				_delay_us(100);
			}
    }
}

