/*
 * Timer_ISR_blinkLED_template.c
 *
 * Created: 6-12-2022 08:06:49
 * Author : Marco Winkelman
 */ 

#include <avr/io.h>
#define F_CPU               4000000UL
#include <util/delay.h>
#include <avr/interrupt.h>

#define TIMER_PERIOD        0x2000   // toggle freq = 4M/256/8192 = 2 Hz

void PORT_init(void)
{
	PORTB.DIRSET = PIN3_bm;  // output on PB3 (LED0), set pin 3 of PORT B as output
}

ISR(TCA0_OVF_vect) {
	PORTB.OUTTGL = PIN3_bm;  // toggle PB3
	TCA0.SINGLE.INTFLAGS = TCA_SINGLE_OVF_bm;
}

void TCA0_interrupt_init(void)
{
	TCA0.SINGLE.INTCTRL = TCA_SINGLE_OVF_bm;         // set interrupt on timer overflow bit
	TCA0.SINGLE.PER = TIMER_PERIOD;
	TCA0.SINGLE.CTRLA = TCA_SINGLE_CLKSEL_DIV256_gc; // 23.5.1 DIV256 CLKSEL=0x06
	TCA0.SINGLE.CTRLA |= TCA_SINGLE_ENABLE_bm;
	// don't forget to set Global Interrupt Enable bit using sei()
}

int main(void)
{
	PORT_init();
	TCA0_interrupt_init();
	
	sei();

	while (1)
	{
		;
	}
}



